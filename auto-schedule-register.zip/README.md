# auto-schedule-register
It is a slight hassle that we need to register schedule manually every time we read email about meeting schedule. 
Auto Schedule Register reads selected texts and convert it to formated information. And then call a google calendar api to register the schedule.
